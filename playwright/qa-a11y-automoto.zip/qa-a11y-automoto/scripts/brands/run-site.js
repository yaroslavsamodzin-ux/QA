const path = require('path');
const { openBrowser, saveCSV, saveJSON, ensureDir } = require('./common');

async function main() {
  const siteArg = process.argv[2]; // напр.: ss.lv
  if (!siteArg) {
    console.error('Usage: node scripts/brands/run-site.js <site-key>');
    process.exit(1);
  }

  const fileName = siteArg.replace(/\W+/g, ''); // "ss.lv" -> "sslv"
  const modPath = path.join(__dirname, 'sites', `${fileName}.js`);

  let siteModule;
  try {
    siteModule = require(modPath);
  } catch (e) {
    console.error(`Cannot load site module: ${modPath}`);
    console.error(e.message);
    process.exit(1);
  }

  const { key, url, scrape } = siteModule;
  if (!url || typeof scrape !== 'function') {
    console.error('Site module must export { key, url, scrape(page) }');
    process.exit(1);
  }

  const outDir = path.join(process.cwd(), 'reports', 'brands');
  ensureDir(outDir);

  const { browser, page } = await openBrowser();
  try {
    console.log(`[OPEN] ${key} — ${url}`);
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 120000 });

    const rows = await scrape(page);
    rows.sort((a,b) => (b.count||0) - (a.count||0));

    const baseName = fileName; // sslv
    const csvPath  = path.join(outDir, `${baseName}.csv`);
    const jsonPath = path.join(outDir, `${baseName}.json`);

    saveCSV(rows, csvPath);
    saveJSON(rows, jsonPath);

    console.log(`[OK] ${rows.length} брендів. Збережено:`);
    console.log('    ', csvPath);
    console.log('    ', jsonPath);
  } finally {
    await browser.close();
  }
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
