// scripts/brands/common.js (CommonJS)
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

function ensureDir(p) { if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true }); }

function toCsv(rows, headerOrder) {
  const header = headerOrder.join(',');
  const body = rows.map(r => headerOrder.map(h => (r[h] ?? '')).join(',')).join('\n');
  return header + '\n' + body + '\n';
}

function saveSiteCsv(siteKey, rows) {
  const outDir = path.join('reports', 'brands', siteKey);
  ensureDir(outDir);
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const csv = toCsv(rows, ['site', 'brand', 'count']);
  const file = path.join(outDir, `${siteKey}__brands__${stamp}.csv`);
  fs.writeFileSync(file, csv, 'utf8');
  console.log(`[SAVE] ${file} (rows=${rows.length})`);
  return file;
}

/** Нормалізація бренду (обрізаємо пробіли, приводимо до Title Case для краси) */
function normalizeBrand(name) {
  const t = (name || '').replace(/\s+/g, ' ').trim();
  if (!t) return t;
  return t.toLowerCase().split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}

/** Парсить рядок "(123)" -> 123 */
function parseCountLike(text) {
  if (!text) return null;
  const m = String(text).match(/(\d[\d\s.,]*)/);
  if (!m) return null;
  return parseInt(m[1].replace(/[^\d]/g, ''), 10) || null;
}

/** Проста кнопка cookies за CSS-селектором (ігнорує помилки) */
async function acceptCookies(page, selectors = []) {
  for (const sel of selectors) {
    try {
      const btn = await page.$(sel);
      if (btn) { await btn.click({ timeout: 1000 }); console.log(`[cookies] clicked ${sel}`); return; }
    } catch {}
  }
}

/** Запуск браузера/сторінки з дефолтними опціями */
async function makeBrowser(headless = true) {
  const browser = await chromium.launch({ headless });
  const context = await browser.newContext();
  const page = await context.newPage();
  return { browser, context, page };
}

module.exports = {
  ensureDir, saveSiteCsv, normalizeBrand, parseCountLike, acceptCookies, makeBrowser
};
// В КІНЕЦЬ scripts/brands/common.js додай:
async function smartExtractBrands(page, opts = {}) {
  const {
    brandSelectors = [],
    countSelectorsNear = ['.count', '.badge', '.nr', '.num', '.qty'],
    preferSameNode = true, // спершу шукаємо числа в тому ж вузлі (напр. "Audi (123)")
  } = opts;

  return await page.evaluate(({ brandSelectors, countSelectorsNear, preferSameNode }) => {
    const seen = new Map(); // brandText -> count (агрегація)
    const norm = s => (s || '').replace(/\s+/g,' ').trim();
    const parseCount = t => {
      if (!t) return null;
      const m = String(t).match(/(\d[\d\s.,]*)/);
      return m ? parseInt(m[1].replace(/[^\d]/g,''), 10) || 0 : null;
    };
    const add = (brand, count) => {
      brand = norm(brand);
      if (!brand) return;
      const prev = seen.get(brand) || 0;
      seen.set(brand, prev + (count || 0));
    };

    // 0) fallback — взяти всі <a> і поруч шукати (N)
    const tryGenericAnchors = () => {
      const anchors = Array.from(document.querySelectorAll('a'));
      for (const a of anchors) {
        const brandText = norm(a.textContent);
        if (!brandText) continue;

        // 0.1 — спробувати знайти число в тому ж тексті
        if (preferSameNode) {
          const countSame = parseCount(brandText);
          if (countSame !== null) {
            // Вирізаємо зайві “(123)” з бренду
            const brandOnly = brandText.replace(/\(\s*\d[\d\s.,]*\s*\)/g,'').trim();
            add(brandOnly, countSame);
            continue;
          }
        }

        // 0.2 — шукати поряд у найближчих сусідах
        const near = [a.nextSibling, a.nextElementSibling, a.parentElement?.nextSibling, a.parentElement?.nextElementSibling]
          .filter(Boolean);
        let countNear = null;
        for (const n of near) {
          const t = norm(n.textContent || '');
          const c = parseCount(t);
          if (c !== null) { countNear = c; break; }
        }
        if (countNear !== null) add(brandText, countNear);
      }
    };

    // 1) Якщо вказали списки селекторів для бренду — пройдемося ними
    const tryExplicitSelectors = () => {
      for (const sel of brandSelectors) {
        const nodes = Array.from(document.querySelectorAll(sel));
        if (!nodes.length) continue;

        for (const el of nodes) {
          const brandText = norm(el.textContent);
          if (!brandText) continue;

          // 1.1 — число всередині того ж елемента
          let count = null;
          if (preferSameNode) {
            count = parseCount(brandText);
            if (count !== null) {
              const brandOnly = brandText.replace(/\(\s*\d[\d\s.,]*\s*\)/g,'').trim();
              add(brandOnly, count);
              continue;
            }
          }

          // 1.2 — числа в дочірніх/сусідніх елементах за типовими класами
          for (const cs of countSelectorsNear) {
            const cEl = el.querySelector(cs) || el.nextElementSibling?.querySelector?.(cs) || el.parentElement?.querySelector?.(cs);
            if (cEl) {
              const c = parseCount(norm(cEl.textContent || ''));
              if (c !== null) { add(brandText, c); count = c; break; }
            }
          }
          if (count !== null) continue;

          // 1.3 — спробувати текст сусідніх вузлів
          const near = [el.nextSibling, el.nextElementSibling, el.parentElement?.nextSibling, el.parentElement?.nextElementSibling]
            .filter(Boolean);
          for (const n of near) {
            const c = parseCount(norm(n.textContent || ''));
            if (c !== null) { add(brandText, c); break; }
          }
        }
      }
    };

    // 2) Спискові елементи
    const tryListItems = () => {
      const lis = Array.from(document.querySelectorAll('ul li, ol li, .list li, .items li'));
      for (const li of lis) {
        const t = norm(li.textContent);
        const c = parseCount(t);
        if (c !== null) {
          const brandOnly = t.replace(/\(\s*\d[\d\s.,]*\s*\)/g,'').trim();
          if (brandOnly && /\D/.test(brandOnly)) add(brandOnly, c);
        }
      }
    };

    tryExplicitSelectors();
    tryListItems();
    tryGenericAnchors();

    return [...seen.entries()].map(([brand, count]) => ({ brand, count }));
  }, { brandSelectors, countSelectorsNear, preferSameNode });
}

module.exports = {
  // ... інші експорти ...
  smartExtractBrands
};
