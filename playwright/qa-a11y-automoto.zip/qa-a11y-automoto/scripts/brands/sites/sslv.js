// scripts/brands/sites/xxx.js
const { smartExtractBrands, normalizeBrand } = require('../common');

module.exports = {
  key: 'ss.lv',
  url: 'https://www.ss.lv/ru/transport/cars/',
  scrape: async (page) => {
    // (опціонально) клік по кукі-банеру тут
    // await acceptCookies(page, [...]);

    const rows = await smartExtractBrands(page, {
      brandSelectors: [
        '.brand-list a',      // ← сюди підставиш свої селектори для сайту
        '.makes a',
        '.marques a',
      ],
      countSelectorsNear: ['.count', '.badge', '.nr', '.num'] // можна не чіпати
    });

    // привести бренд до охайного вигляду
    return rows.map(r => ({ site: 'ss.lv', brand: normalizeBrand(r.brand), count: r.count }))
  }
};

