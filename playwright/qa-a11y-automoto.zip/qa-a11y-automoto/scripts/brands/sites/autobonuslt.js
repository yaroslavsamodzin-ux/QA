// scripts/sites/autobonuslt.js
import { acceptCookiesIfPresent } from '../common.js';
import fs from 'fs';
import path from 'path';
import { URL } from 'url';

const BASE_URL =
  'https://www.autobonus.lt/avto/poisk/?search=1&cat=1&collapsrch=1&ussearch=&saveusersearch=1&ma=-1&mo=-1&bo=-1&fu=-1&ge=-1&p1=&p2=&y1=-1&y2=-1&doSearch=1';

function norm(s) {
  return (s || '')
    .replace(/\s+/g, ' ')
    .replace(/[‐–—−]+/g, '-') // різні дефіси -> "-"
    .trim()
    .toLowerCase();
}

// Локальні аліаси для кращого матчінгу назв
function normalizeBrand(s) {
  const x = norm(s);
  const aliases = new Map([
    ['mercedes', 'mercedes-benz'],
    ['mercedes benz', 'mercedes-benz'],
    ['vw', 'volkswagen'],
    ['land rover', 'land-rover'],
  ]);
  return aliases.get(x) || x;
}

export default {
  key: 'autobonuslt',
  url: BASE_URL,

  async scrape(page, brands) {
    // 1) відкрити базову сторінку пошуку
    await page.goto(BASE_URL, { waitUntil: 'domcontentloaded', timeout: 45000 });
    await acceptCookiesIfPresent(page);

    // 2) зібрати мапу "label -> value" з select[name="ma"]
    const options = await page.$$eval('select[name="ma"] option', opts =>
      opts.map(o => ({ text: (o.textContent || '').trim(), value: o.value }))
    );

    // відфільтрувати службові пункти
    const optionMap = new Map();
    for (const o of options) {
      const label = o.text
        .replace(/^[-–—]?\s*Показывать.*$/i, '')
        .replace(/^[-–—]?\s*Другая.*$/i, '')
        .replace(/^all.*$/i, '')
        .trim();
      if (!label || label.length < 2 || !o.value) continue;
      optionMap.set(label, o.value);
    }

    // індекс по нормалізованих назвах
    const idx = new Map();
    for (const [label, value] of optionMap.entries()) {
      idx.set(normalizeBrand(label), { label, value });
    }

    // 3) функція отримання лічильника для конкретного value
    async function countForOptionValue(val) {
      const u = new URL(BASE_URL);
      u.searchParams.set('ma', val);
      u.searchParams.set('doSearch', '1');
      await page.goto(u.toString(), { waitUntil: 'domcontentloaded', timeout: 45000 });
      await acceptCookiesIfPresent(page);

      // спробувати витягти "загальну кількість" з заголовка/сумарного блоку
      const candidates = [
        '.results-count',
        '.result-count',
        '.searchResultCount',
        '.srchTxt',
        '.content h1',
        '.centercol h1',
        'h1',
        'h2'
      ];
      for (const sel of candidates) {
        const el = await page.$(sel);
        if (el) {
          const t = ((await el.textContent()) || '').replace(/\s+/g, ' ').trim();
          const m = t.match(/(\d{1,7})/);
          if (m) return parseInt(m[1], 10);
        }
      }

      // fallback: кількість карток на сторінці (нижня межа, якщо нема total)
      const cardSelectors = [
        '.srchres .srchres-item',
        '.items .item',
        '.auto-list .item',
        '.products .product'
      ];
      for (const cs of cardSelectors) {
        const n = await page.$$eval(cs, els => els.length).catch(() => 0);
        if (n > 0) return n;
      }

      // дебаг: зберегти HTML для аналізу
      try {
        const outDir = path.join(process.cwd(), 'out');
        if (!fs.existsSync(outDir)) fs.mkdirSync(outDir);
        fs.writeFileSync(path.join(outDir, `autobonuslt_debug_${val}.html`), await page.content(), 'utf-8');
      } catch {}
      return 0;
    }

    // 4) основний цикл по твоєму списку брендів
    const rows = [];
    for (const brand of brands) {
      const rec = idx.get(normalizeBrand(brand));
      let count = 0;
      if (rec && rec.value !== '-1') {
        try {
          count = await countForOptionValue(rec.value);
        } catch (e) {
          // залишаємо 0
        }
      }
      rows.push({ brand, count });
      if (rows.length % 10 === 0) console.log(`[autobonuslt] ${rows.length}/${brands.length} done`);
      await page.waitForTimeout(150); // трохи повільніше, щоб сайт не банив
    }

    return rows;
  }
};
