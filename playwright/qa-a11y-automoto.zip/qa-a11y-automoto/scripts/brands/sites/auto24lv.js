// scripts/brands/sites/xxx.js
const { smartExtractBrands, normalizeBrand } = require('../common');

module.exports = {
  key: 'auto24.lv',
  url: 'https://www.auto24.lv/',
  scrape: async (page) => {
    // (опціонально) клік по кукі-банеру тут
    // await acceptCookies(page, [...]);

    const rows = await smartExtractBrands(page, {
      brandSelectors: [
        '.brand-list a',      // ← сюди підставиш свої селектори для сайту
        '.makes a',
        '.marques a',
      ],
      countSelectorsNear: ['.count', '.badge', '.nr', '.num'] // можна не чіпати
    });

    // привести бренд до охайного вигляду
    return rows.map(r => ({ site: 'auto24.lv', brand: normalizeBrand(r.brand), count: r.count }))
  }
};

